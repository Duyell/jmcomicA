from typing import NamedTuple

from .jm_option import *


def catch_exception(func):
    from functools import wraps

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        self: JmDownloader
        try:
            return func(self, *args, **kwargs)
        except Exception as e:
            detail: JmBaseEntity = args[0]
            if detail.is_image():
                detail: JmImageDetail
                jm_log('image.failed', f'图片下载失败: [{detail.download_url}], 异常: [{e}]', e)
                self.download_failed_image.append((detail, e))

            elif detail.is_photo():
                detail: JmPhotoDetail
                jm_log('photo.failed', f'章节下载失败: [{detail.id}], 异常: [{e}]', e)
                self.download_failed_photo.append((detail, e))

            raise e

    return wrapper


# noinspection PyMethodMayBeStatic
class DownloadCallback:

    def before_album(self, album: JmAlbumDetail):
        jm_log('album.before',
               f'本子获取成功: [{album.id}], '
               f'作者: [{album.author}], '
               f'章节数: [{len(album)}], '
               f'总页数: [{album.page_count}], '
               f'标题: [{album.name}], '
               f'关键词: {album.tags}'
               )

    def after_album(self, album: JmAlbumDetail):
        jm_log('album.after', f'本子下载完成: [{album.id}]')

    def before_photo(self, photo: JmPhotoDetail):
        jm_log('photo.before',
               f'开始下载章节: {photo.id} ({photo.album_id}[{photo.index}/{len(photo.from_album)}]), '
               f'标题: [{photo.name}], '
               f'图片数为[{len(photo)}]'
               )

    def after_photo(self, photo: JmPhotoDetail):
        jm_log('photo.after',
               f'章节下载完成: [{photo.id}] ({photo.album_id}[{photo.index}/{len(photo.from_album)}])')

    def before_image(self, image: JmImageDetail, img_save_path):
        if image.exists and image.cache:
            jm_log('image.before',
                   f'图片已存在: {image.tag} ← [{img_save_path}]'
                   )
            return
        jm_log('image.before',
               f'图片准备下载: {image.tag}, [{image.img_url}] → [{img_save_path}]'
               )

    def after_image(self, image: JmImageDetail, img_save_path):
        jm_log('image.after',
               f'图片下载完成: {image.tag}, [{image.img_url}] → [{img_save_path}]')


class BaseDownloader(DownloadCallback):
    """
    不含 I/O 调度的公共基类，负责回调、钩子、Features 注册等无 I/O 通用逻辑。
    """

    def __init__(self, option: JmOption):
        self.option = option
        self.client = None
        # 下载成功的记录dict
        self.download_success_dict: Dict[JmAlbumDetail, Dict[JmPhotoDetail, List[Tuple[str, JmImageDetail]]]] = {}
        # 下载失败的记录list
        self.download_failed_image: List[Tuple[JmImageDetail, BaseException]] = []
        self.download_failed_photo: List[Tuple[JmPhotoDetail, BaseException]] = []
        # Feature 特性列表: [(feature, feature_from), ...]
        self._feature_list: List[Tuple] = []

    def do_filter(self, detail: DetailEntity):
        """
        该方法可用于过滤本子/章节，默认不会做过滤。
        例如:
        只想下载 本子的最新一章，返回 [album[-1]]
        只想下载 章节的前10张图片，返回 [photo[:10]]

        :param detail: 可能是本子或者章节，需要自行使用 isinstance / detail.is_xxx 判断
        :returns: 只想要下载的 本子的章节 或 章节的图片
        """
        return detail

    @property
    def all_success(self) -> bool:
        """
        是否成功下载了全部图片

        该属性需要等到downloader的全部download_xxx方法完成后才有意义。

        注意！如果使用了filter机制，例如通过filter只下载3张图片，那么all_success也会为False
        """
        if self.has_download_failures:
            return False

        for album, photo_dict in self.download_success_dict.items():
            if len(album) != len(photo_dict):
                return False

            for photo, image_list in photo_dict.items():
                if len(photo) != len(image_list):
                    return False

        return True

    @property
    def has_download_failures(self):
        return len(self.download_failed_image) != 0 or len(self.download_failed_photo) != 0

    # 下面是回调方法

    def before_album(self, album: JmAlbumDetail):
        super().before_album(album)
        self.download_success_dict.setdefault(album, {})
        self.option.call_all_plugin(
            'before_album',
            album=album,
            downloader=self,
        )

    def after_album(self, album: JmAlbumDetail):
        super().after_album(album)
        self.option.call_all_plugin(
            'after_album',
            album=album,
            downloader=self,
        )
        # 触发匹配 after_album 的 Feature
        self._invoke_features_for('after_album', album=album, downloader=self)

    def before_photo(self, photo: JmPhotoDetail):
        super().before_photo(photo)
        self.download_success_dict.setdefault(photo.from_album, {})
        self.download_success_dict[photo.from_album].setdefault(photo, [])
        self.option.call_all_plugin(
            'before_photo',
            photo=photo,
            downloader=self,
        )

    def after_photo(self, photo: JmPhotoDetail):
        super().after_photo(photo)
        self.option.call_all_plugin(
            'after_photo',
            photo=photo,
            downloader=self,
        )
        # 触发匹配 after_photo 的 Feature
        self._invoke_features_for('after_photo', photo=photo, downloader=self)

    def before_image(self, image: JmImageDetail, img_save_path):
        super().before_image(image, img_save_path)
        self.option.call_all_plugin(
            'before_image',
            image=image,
            downloader=self,
        )

    def after_image(self, image: JmImageDetail, img_save_path):
        super().after_image(image, img_save_path)
        photo = image.from_photo
        album = photo.from_album

        self.download_success_dict.get(album).get(photo).append((img_save_path, image))
        self.option.call_all_plugin(
            'after_image',
            image=image,
            downloader=self,
        )

    def add_features(self, features, feature_from: str):
        """
        注册 Feature 及其来源。

        :param features: Feature / FeatureChain / list / None
        :param feature_from: 来源标记，如 'download_album' 或 'download_photo'
        """
        if features is None:
            return

        from .jm_feature import FeatureChain, Feature
        from .jm_toolkit import ExceptionTool

        if isinstance(features, list):
            for f in features:
                self.add_features(f, feature_from)
        elif isinstance(features, FeatureChain):
            for f in features.to_list():
                self._feature_list.append((f, feature_from))
        elif isinstance(features, Feature):
            self._feature_list.append((features, feature_from))
        else:
            ExceptionTool.raises(f'不支持的 extra 类型: {type(features)}，请传入 Feature / FeatureChain / list / None')

    def _invoke_features_for(self, when: str, **kwargs):
        """
        在指定钩子(when)中触发匹配的 Feature。

        :param when: 当前钩子名，如 'after_album', 'after_photo'
        :param kwargs: album, photo, downloader 等上下文
        """
        for feature, feature_from in self._feature_list:
            if feature.should_invoke(feature_from, when):
                try:
                    feature.invoke(self.option, feature_from=feature_from, when=when, **kwargs)
                except Exception as e:
                    jm_log('downloader.feature.exception', f'Feature执行失败: [{feature}], 来源: [{feature_from}], 异常: [{e}]',
                           e)

    def raise_if_has_exception(self):
        if not self.has_download_failures:
            return
        msg_ls = ['部分下载失败', '', '']

        if len(self.download_failed_photo) != 0:
            msg_ls[1] = f'共{len(self.download_failed_photo)}个章节下载失败: {self.download_failed_photo}'

        if len(self.download_failed_image) != 0:
            msg_ls[2] = f'共{len(self.download_failed_image)}个图片下载失败: {self.download_failed_image}'

        ExceptionTool.raises(
            '\n'.join(msg_ls),
            {'downloader': self},
            PartialDownloadFailedException,
        )


class DownloadResult(NamedTuple):
    """单个下载结果。

    支持解包：album, dler = download_album(id)
    也支持属性访问：result.detail, result.downloader
    NamedTuple 是 tuple 子类，isinstance(result, tuple) 为 True。
    """
    detail: DetailEntity
    downloader: BaseDownloader


class BatchResult(set):
    """批量下载结果集。

    继承 set，完全兼容旧写法 for album, dler in result。
    新增 .failed 属性，记录失败的 jm_id 和对应异常。
    """

    def __init__(self):
        super().__init__()
        self.failed: Dict[str, BaseException] = {}

    @property
    def all_succeeded(self) -> bool:
        return len(self.failed) == 0

    @property
    def total(self) -> int:
        """预期总数（成功 + 失败）"""
        return len(self) + len(self.failed)


class JmDownloader(BaseDownloader):
    """
    JmDownloader = BaseDownloader + 同步 I/O 调度逻辑
    """

    def __init__(self, option: JmOption):
        super().__init__(option)
        self.client = self.create_client()

    def create_client(self):
        """
        创建该downloader使用的client。
        """
        return self.option.build_jm_client()

    def download_album(self, album_id):
        album = self.client.get_album_detail(album_id)
        self.download_by_album_detail(album)
        return album

    def download_by_album_detail(self, album: JmAlbumDetail):
        self.before_album(album)
        if album.skip:
            return
        self.execute_on_condition(
            iter_objs=album,
            apply=self.download_by_photo_detail,
            count_batch=self.option.decide_photo_batch_count(album)
        )
        self.after_album(album)

    def download_photo(self, photo_id):
        photo = self.client.get_photo_detail(photo_id)
        self.download_by_photo_detail(photo)
        return photo

    @catch_exception
    def download_by_photo_detail(self, photo: JmPhotoDetail):
        self.client.check_photo(photo)

        self.before_photo(photo)
        if photo.skip:
            return
        self.execute_on_condition(
            iter_objs=photo,
            apply=self.download_by_image_detail,
            count_batch=self.option.decide_image_batch_count(photo)
        )
        self.after_photo(photo)

    @catch_exception
    def download_by_image_detail(self, image: JmImageDetail):
        img_save_path = self.option.decide_image_filepath(image)

        image.save_path = img_save_path
        image.exists = file_exists(img_save_path)
        image.cache = self.option.decide_download_cache(image)

        self.before_image(image, img_save_path)

        if image.skip:
            return

        # let option decide use_cache and decode_image
        decode_image = self.option.decide_download_image_decode(image)

        # skip download
        if image.cache and image.exists:
            return

        self.client.download_by_image_detail(
            image,
            img_save_path,
            decode_image=decode_image,
        )

        self.after_image(image, img_save_path)

    def execute_on_condition(self,
                             iter_objs: DetailEntity,
                             apply: Callable,
                             count_batch: int,
                             ):
        """
        调度本子/章节的下载
        """
        iter_objs = self.do_filter(iter_objs)
        count_real = len(iter_objs)

        if count_real == 0:
            return

        if count_batch >= count_real:
            # 一个图/章节 对应 一个线程
            multi_thread_launcher(
                iter_objs=iter_objs,
                apply_each_obj_func=apply,
            )
        else:
            # 创建batch个线程的线程池
            thread_pool_executor(
                iter_objs=iter_objs,
                apply_each_obj_func=apply,
                max_workers=count_batch,
            )

    # 下面是对with语法的支持

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            jm_log('dler.exception',
                   f'{self.__class__.__name__} Exit with exception: {exc_type, str(exc_val)}'
                   )

    @classmethod
    def use(cls, *args, **kwargs):
        """
        让本类替换JmModuleConfig.CLASS_DOWNLOADER
        """
        JmModuleConfig.CLASS_DOWNLOADER = cls


class DoNotDownloadImage(JmDownloader):
    """
    不会下载任何图片的Downloader，用作测试
    """

    def download_by_image_detail(self, image: JmImageDetail):
        # ensure make dir
        self.option.decide_image_filepath(image)


class JustDownloadSpecificCountImage(JmDownloader):
    """
    只下载特定数量图片的Downloader，用作测试
    """
    from threading import Lock

    count_lock = Lock()
    count = 0

    @catch_exception
    def download_by_image_detail(self, image: JmImageDetail):
        # ensure make dir
        self.option.decide_image_filepath(image)

        if self.try_countdown():
            return super().download_by_image_detail(image)

    def try_countdown(self):
        if self.count < 0:
            return False

        with self.count_lock:
            if self.count < 0:
                return False

            self.count -= 1

            return self.count >= 0

    @classmethod
    def use(cls, count):
        cls.count = count
        super().use()
